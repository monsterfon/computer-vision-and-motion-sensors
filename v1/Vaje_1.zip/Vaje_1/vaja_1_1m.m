DATA_A = readtable('data_1m_2\Accelerometer.csv');
DATA_G = readtable('data_1m_2\Gravity.csv');

clear t a a_g
for i = 1:size(DATA_A,1)
    t(i) = DATA_A(i,2).seconds_elapsed;
    a(i,1) = DATA_A(i,5).x;
    a(i,2) = DATA_A(i,4).y;
    a(i,3) = DATA_A(i,3).z;
end

t = t - t(1);
plot(t, a)
xlabel("Čas [s]")
ylabel("Pospešek [m/s2]")
legend({'x','y', 'z'})

% pospešek z dodano gravitacijo
for i = 1:size(DATA_G,1)
    a_g(i, 1) = a(i, 1) + DATA_G(i, 5).x;
    a_g(i, 2) = a(i, 2) + DATA_G(i, 4).y;
    a_g(i, 3) = a(i, 3) + DATA_G(i, 3).z;
end

figure;
plot(t, a_g)
xlabel("Čas [s]")
ylabel("Pospešek [m/s2]")
legend({'x','y', 'z'})

% a(:,1) = a(:,1) - mean(a(1:400,1));
% a(:,2) = a(:,2) - mean(a(1:400,2));
% a(:,3) = a(:,3) - mean(a(1:400,3));
% plot(t, a)

clear v s
deltaT = t(2:end) - t(1:end-1);
v(1, :) = [0 0 0];
s(1, :) = [0 0 0];
for i = 2:size(DATA_A,1)-1
    v(i, :) = v(i-1, :) + a(i-1, :)*deltaT(i); 
    s(i, :) = s(i-1, :) + v(i-1, :)*deltaT(i) + 1/2*a(i-1, :)*deltaT(i)*deltaT(i);
end
figure;
plot(t(1:end-1), v)
xlabel("Čas [s]")
ylabel("Hitrost")
figure;
plot(t(1:end-1), s)
xlabel("Čas [s]")
ylabel("Pot")

% pr odštevanju za zadnjo nalogo vzem čim lepši pospešek na začetku/na konc
% al pa oboje
% ampak baje da so meritve lepe do tm, več niso
% odštej povprečje "nične" meritve da se znebiš napake senzorja
