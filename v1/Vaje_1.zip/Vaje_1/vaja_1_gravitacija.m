DATA = readtable('data/Gravity.csv');

clear t a

for i = 1:size(DATA,1)
    t(i) = DATA(i,2).seconds_elapsed;
    a(i,1) = DATA(i,5).x;
    a(i,2) = DATA(i,4).y;
    a(i,3) = DATA(i,3).z;
end

t = t - t(1);
plot(t, a)
xlabel("Čas [s]")
ylabel("Pospešek [m/s2]")
legend({'x','y', 'z'})


