% Load the data
data = readtable('meter9.csv');
clear t a;

for i = 1:size(data,1)
    t(i) = (data.SamplingTime(i) - time(1)) / 1e9; 
    a(i,1) = data.AccelerationX(i);
    a(i,2) = data.AccelerationY(i);
    a(i,3) = data.AccelerationZ(i);
end
t = t - t(1);
plot(a)


a(:,1) = a(:,1) - mean(a(1:65,1));
a(:,2) = a(:,2) - mean(a(1:65,2));
a(:,3) = a(:,3) - mean(a(1:65,3));
plot(t, a)

clear v s
deltaT = t(2:end) - t(1:end-1);
v(1, :) = [0 0 0];
s(1, :) = [0 0 0];
for i = 2:size(data,1)-1
    v(i, :) = v(i-1, :) + a(i-1, :)*deltaT(i)*9.81; 
    s(i, :) = s(i-1, :) + v(i-1, :)*deltaT(i) + 1/2*a(i-1, :)*deltaT(i)*deltaT(i)*9.8;
end
plot(t(1:end-1), v)
%plot(t(1:end-1), s)






%{
figure;
plot(time, accelX, 'r', 'DisplayName', 'Acceleration X');
hold on;
plot(time, accelY, 'g', 'DisplayName', 'Acceleration Y');
plot(time, accelZ, 'b', 'DisplayName', 'Acceleration Z');
hold off;

xlabel('Time (s)');
ylabel('Acceleration (m/s^2)');
title('Acceleration vs. Time');
legend show;
%}



