clear;
addpath('libVaje');

DATA = readtable('data_2/Gyroscope.csv');

for i = 1:size(DATA,1)
    t(i) = DATA(i,2).seconds_elapsed;
    omega(i,1) = DATA(i,5).x;
    omega(i,2) = DATA(i,4).y;
    omega(i,3) = DATA(i,3).z;
end

t = t - t(1);
plot(t, omega)
xlabel("Čas [s]")
ylabel("Kotna hitrost [deg/s2]")
legend({'x','y', 'z'})

% R = fnRotacijskaMatrika(2*pi/3, [1,1,1]/sqrt(3))

d_t = t(2:end) - t(1:end-1);

S(1,:,:) = eye(3);
S_q(1,:,:) = eye(3);
for i = 1:size(omega,1)-1
    phi(i) = sqrt(sum(omega(i,:).^2)) * d_t(i)*pi/180;
    os(i,:) = omega(i,:)/sqrt(sum(omega(i,:).^2));
    
    R = fnRotacijskaMatrika(phi(i), os(i,:));
    q = fnRotacijskiKvaternion(phi(i), os(i,:));
    
    % S(i+1,:,:) = squeeze(S(i,:,:)) * R;
    S(i+1,:,:) = fnRotirajZMatriko(squeeze(S(i,:,:)), R);
    S_q(i+1,:,:) = fnRotirajSKvaternionom(squeeze(S_q(i,:,:)), q);
end

S_final = reshape(S(end,:,:), 3, 3)
S_q_final = reshape(S_q(end,:,:), 3, 3)

% scrAnimirajRotacijo

% % todo nč se ne premika
% figure;
% fnIzrisiKS(reshape(S(13000,:,:), 3, 3)); pause(0.00000001);
% for j=13000:size(omega,1)
%     fnIzrisiGKS(), hold on
%     fnIzrisiKS(reshape(S(j,:,:), 3, 3)); pause(0.00000001);
% end


% odmik od stacionarnega stanja
odmik_x = mean(omega(1000:10000, 1))
odmik_y = mean(omega(1000:10000, 2))
odmik_z = mean(omega(1000:10000, 3))
